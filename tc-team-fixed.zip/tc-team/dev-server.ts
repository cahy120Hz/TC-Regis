// Server lokal: menjalankan handler di folder api/ persis seperti di Vercel.
// Jalankan: npm run dev   (butuh .env terisi)
import 'dotenv/config';
import express from 'express';
import path from 'node:path';
import { fileURLToPath } from 'node:url';

import register from './api/register.js';
import members from './api/members.js';
import login from './api/admin/login.js';
import logout from './api/admin/logout.js';
import stats from './api/admin/stats.js';
import registrations from './api/admin/registrations.js';
import exportCsv from './api/admin/export/csv.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const PORT = Number(process.env.PORT) || 3000;
const app = express();

app.set('trust proxy', true);
app.use(express.json({ limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));

const h = (fn: any) => (req: any, res: any) => Promise.resolve(fn(req, res));

app.all('/api/register', h(register));
app.all('/api/members', h(members));
app.all('/api/admin/login', h(login));
app.all('/api/admin/logout', h(logout));
app.all('/api/admin/stats', h(stats));
app.all('/api/admin/registrations', h(registrations));
app.all('/api/admin/export/csv', h(exportCsv));

app.get('/health', (_req, res) => res.json({ status: 'ok', timestamp: new Date().toISOString() }));
app.use((_req, res) => res.status(404).json({ error: 'Not found' }));

app.listen(PORT, () => {
  console.log(`TC dev server: http://localhost:${PORT}  |  admin: http://localhost:${PORT}/admin.html`);
  if (!process.env.SUPABASE_URL) console.warn('! SUPABASE_URL kosong — isi .env dulu supaya register/members/admin jalan');
});
