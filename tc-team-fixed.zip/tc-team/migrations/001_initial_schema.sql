-- Create private registrations table
CREATE TABLE IF NOT EXISTS registrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  full_name TEXT NOT NULL,
  phone TEXT NOT NULL,
  tiktok TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW(),
  updated_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_registrations_phone ON registrations(phone);
CREATE INDEX idx_registrations_created_at ON registrations(created_at DESC);

-- Create public registrations view
CREATE TABLE IF NOT EXISTS public_registrations (
  id UUID PRIMARY KEY DEFAULT gen_random_uuid(),
  registration_id UUID NOT NULL REFERENCES registrations(id) ON DELETE CASCADE,
  display_name TEXT NOT NULL,
  tiktok TEXT NOT NULL,
  created_at TIMESTAMP WITH TIME ZONE DEFAULT NOW()
);

CREATE INDEX idx_public_registrations_created_at ON public_registrations(created_at DESC);

-- Enable RLS
ALTER TABLE registrations ENABLE ROW LEVEL SECURITY;
ALTER TABLE public_registrations ENABLE ROW LEVEL SECURITY;

-- RLS Policies for registrations (private)
CREATE POLICY "registrations_admin_select" ON registrations
  FOR SELECT
  USING (auth.role() = 'authenticated');

CREATE POLICY "registrations_anon_insert" ON registrations
  FOR INSERT
  WITH CHECK (true);

-- RLS Policies for public_registrations
CREATE POLICY "public_registrations_select" ON public_registrations
  FOR SELECT
  USING (true);

CREATE POLICY "public_registrations_insert" ON public_registrations
  FOR INSERT
  WITH CHECK (true);
