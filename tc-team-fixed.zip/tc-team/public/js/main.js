import { initializeApp } from 'https://www.gstatic.com/firebasejs/10.5.0/firebase-app.js';

const SUPABASE_URL = import.meta.env.VITE_SUPABASE_URL || '';
const SUPABASE_ANON_KEY = import.meta.env.VITE_SUPABASE_ANON_KEY || '';

const API_BASE = window.location.origin;

class FormManager {
  constructor() {
    this.form = document.getElementById('register-form');
    this.currentStep = 1;
    this.formData = {
      phone: '',
      fullname: '',
      tiktok: ''
    };
    this.isSubmitting = false;
    this.init();
  }

  init() {
    this.attachEventListeners();
    this.updateProgressIndicator();
  }

  attachEventListeners() {
    const nextButtons = document.querySelectorAll('.form-next');
    const backButtons = document.querySelectorAll('.form-back');

    nextButtons.forEach(btn => {
      btn.addEventListener('click', (e) => this.handleNext(e));
    });

    backButtons.forEach(btn => {
      btn.addEventListener('click', (e) => this.handleBack(e));
    });

    this.form.addEventListener('submit', (e) => this.handleSubmit(e));

    const phoneInput = document.getElementById('phone');
    const fullnameInput = document.getElementById('fullname');
    const tiktokInput = document.getElementById('tiktok');

    phoneInput?.addEventListener('input', (e) => {
      this.formData.phone = e.target.value;
    });

    fullnameInput?.addEventListener('input', (e) => {
      this.formData.fullname = e.target.value;
    });

    tiktokInput?.addEventListener('input', (e) => {
      this.formData.tiktok = e.target.value;
    });
  }

  handleNext(e) {
    e.preventDefault();
    const nextStep = parseInt(e.target.dataset.next);

    if (this.validateStep(this.currentStep)) {
      this.showStep(nextStep);
      this.currentStep = nextStep;
      this.updateProgressIndicator();
      if (nextStep === 3) {
        this.populateReview();
      }
    }
  }

  handleBack(e) {
    e.preventDefault();
    const prevStep = parseInt(e.target.dataset.back);
    this.showStep(prevStep);
    this.currentStep = prevStep;
    this.updateProgressIndicator();
  }

  validateStep(step) {
    this.clearErrors();

    if (step === 1) {
      const phone = document.getElementById('phone').value.trim();
      if (!phone) {
        this.showError('phone', 'Phone number is required');
        return false;
      }
      if (!/^[+\d\s\-()]{8,}$/.test(phone)) {
        this.showError('phone', 'Please enter a valid phone number');
        return false;
      }
      return true;
    }

    if (step === 2) {
      const fullname = document.getElementById('fullname').value.trim();
      const tiktok = document.getElementById('tiktok').value.trim();

      if (!fullname) {
        this.showError('fullname', 'Full name is required');
        return false;
      }
      if (fullname.length > 100) {
        this.showError('fullname', 'Name is too long (max 100 characters)');
        return false;
      }

      if (!tiktok) {
        this.showError('tiktok', 'TikTok username is required');
        return false;
      }
      if (!/^[@]?[\w.]{3,}$/.test(tiktok.replace('@', ''))) {
        this.showError('tiktok', 'Please enter a valid TikTok username');
        return false;
      }

      return true;
    }

    if (step === 3) {
      const agree = document.getElementById('agree').checked;
      if (!agree) {
        this.showError('agree', 'You must agree to continue');
        return false;
      }
      return true;
    }

    return true;
  }

  showError(fieldId, message) {
    const field = document.getElementById(fieldId);
    if (!field) return;

    const formGroup = field.closest('.form-group');
    if (!formGroup) return;

    formGroup.classList.add('error');

    let errorEl = formGroup.querySelector('.form-error');
    if (!errorEl) {
      errorEl = document.createElement('div');
      errorEl.className = 'form-error';
      formGroup.appendChild(errorEl);
    }
    errorEl.textContent = message;
  }

  clearErrors() {
    const errorEls = document.querySelectorAll('.form-error');
    errorEls.forEach(el => el.remove());

    const errorGroups = document.querySelectorAll('.form-group.error');
    errorGroups.forEach(group => group.classList.remove('error'));
  }

  showStep(stepNumber) {
    const steps = document.querySelectorAll('.form-step');
    steps.forEach(step => step.classList.add('hidden'));
    const step = document.querySelector(`[data-step="${stepNumber}"]`);
    if (step) {
      step.classList.remove('hidden');
    }
  }

  updateProgressIndicator() {
    const indicator = document.querySelector('.progress-indicator');
    if (indicator) {
      const steps = indicator.querySelectorAll('.progress-step');
      steps.forEach((step, idx) => {
        step.classList.remove('active', 'completed');
        if (idx + 1 < this.currentStep) {
          step.classList.add('completed');
        } else if (idx + 1 === this.currentStep) {
          step.classList.add('active');
        }
      });
    }
  }

  populateReview() {
    document.getElementById('review-phone').textContent = this.formData.phone;
    document.getElementById('review-name').textContent = this.formData.fullname;
    document.getElementById('review-tiktok').textContent = this.formData.tiktok;
  }

  async handleSubmit(e) {
    e.preventDefault();

    if (this.isSubmitting) return;
    if (!this.validateStep(3)) return;

    this.isSubmitting = true;
    const submitBtn = document.getElementById('submit-btn');
    const originalText = submitBtn.textContent;
    submitBtn.disabled = true;
    submitBtn.innerHTML = '<span class="spinner"></span> SUBMITTING...';

    try {
      const response = await fetch(`${API_BASE}/api/register`, {
        method: 'POST',
        headers: {
          'Content-Type': 'application/json',
          'X-Requested-With': 'XMLHttpRequest'
        },
        body: JSON.stringify({
          phone: this.formData.phone.trim(),
          fullname: this.formData.fullname.trim(),
          tiktok: this.formData.tiktok.trim().replace('@', '')
        })
      });

      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Registration failed');
      }

      this.showSuccessScreen();
    } catch (error) {
      console.error('Registration error:', error);
      this.showError('agree', error.message || 'An error occurred. Please try again.');
    } finally {
      this.isSubmitting = false;
      submitBtn.disabled = false;
      submitBtn.textContent = originalText;
    }
  }

  showSuccessScreen() {
    const form = document.getElementById('register-form');
    const successScreen = document.getElementById('success-screen');

    form.classList.add('hidden');
    successScreen.classList.remove('hidden');

    const joinUrl = window.TC_JOIN_URL;
    const container = document.getElementById('join-link-container');

    if (joinUrl) {
      container.innerHTML = `<a href="${joinUrl}" target="_blank" rel="noopener">Join TC Community on WhatsApp</a>`;
    }
  }
}

class NavigationManager {
  constructor() {
    this.navToggle = document.getElementById('nav-toggle');
    this.navMenu = document.getElementById('nav-menu');
    this.init();
  }

  init() {
    this.navToggle?.addEventListener('click', () => this.toggleMenu());

    const navLinks = document.querySelectorAll('.nav-link');
    navLinks.forEach(link => {
      link.addEventListener('click', () => this.closeMenu());
    });
  }

  toggleMenu() {
    this.navMenu?.classList.toggle('active');
  }

  closeMenu() {
    this.navMenu?.classList.remove('active');
  }
}

class MembersManager {
  constructor() {
    this.container = document.getElementById('members-container');
    this.emptyState = document.getElementById('members-empty-state');
    this.init();
  }

  async init() {
    await this.loadMembers();
    this.setupRealtimeListener();
  }

  async loadMembers() {
    try {
      const response = await fetch(`${API_BASE}/api/members?limit=12`);
      const data = await response.json();

      if (!response.ok) {
        throw new Error(data.error || 'Failed to load members');
      }

      const members = Array.isArray(data.data) ? data.data : (data.data?.items ?? []);

      if (members.length === 0) {
        this.container.classList.add('hidden');
        this.emptyState.classList.remove('hidden');
        return;
      }

      this.container.classList.remove('hidden');
      this.emptyState.classList.add('hidden');
      this.renderMembers(members);
    } catch (error) {
      console.error('Error loading members:', error);
      this.container.innerHTML = '<div class="error-state">Failed to load members. Please refresh.</div>';
      this.emptyState.classList.add('hidden');
    }
  }

  renderMembers(members) {
    this.container.innerHTML = members.map(member => {
      const date = new Date(member.created_at);
      const formattedDate = date.toLocaleDateString('en-US', {
        month: 'short',
        day: 'numeric',
        year: 'numeric'
      });

      return `
        <div class="member-card">
          <div class="member-name">${this.escapeHtml(member.display_name)}</div>
          <div class="member-tiktok">@${this.escapeHtml(member.tiktok)}</div>
          <div class="member-date">${formattedDate}</div>
        </div>
      `;
    }).join('');
  }

  escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
  }

  setupRealtimeListener() {
    // Serverless tidak mendukung koneksi SSE panjang, jadi pakai polling ringan
    setInterval(() => {
      if (!document.hidden) this.loadMembers();
    }, 30000);
  }
}

class CommunitiesManager {
  constructor() {
    this.grid = document.getElementById('communities-grid');
    this.init();
  }

  init() {
    this.loadCommunities();
  }

  loadCommunities() {
    const communities = [
      {
        id: 'tc-main',
        name: 'TC Community',
        description: 'The main hub for all creators, developers, and curious minds.',
        url: window.TC_JOIN_URL || null
      },
      {
        id: 'eas',
        name: 'EAS',
        description: 'Ecosystem and Support community for collaborative projects.',
        url: null
      },
      {
        id: 'star',
        name: 'STAR',
        description: 'Skill Transfer and Resource sharing network.',
        url: null
      }
    ];

    this.renderCommunities(communities);
  }

  renderCommunities(communities) {
    this.grid.innerHTML = communities.map(community => {
      const logo = community.id.toUpperCase().substring(0, 2);
      const linkHtml = community.url 
        ? `<a href="${community.url}" target="_blank" rel="noopener" class="community-link">Join <i class="fa-solid fa-arrow-right"></i></a>`
        : '<span class="community-link" style="opacity: 0.5;">Coming Soon</span>';

      return `
        <div class="community-card">
          <div class="community-logo">${logo}</div>
          <h3 class="community-name">${community.name}</h3>
          <p class="community-description">${community.description}</p>
          ${linkHtml}
        </div>
      `;
    }).join('');
  }
}

class LoadingManager {
  constructor() {
    this.loadingScreen = document.getElementById('loading-screen');
    this.mainContent = document.getElementById('main-content');
    this.init();
  }

  init() {
    setTimeout(() => {
      this.loadingScreen.classList.add('hidden');
      this.mainContent.classList.remove('hidden');
    }, 2000);
  }
}

class UIManager {
  constructor() {
    this.setupScrollBehavior();
    this.setupButtonActions();
    this.updateYear();
  }

  setupScrollBehavior() {
    const registerLink = document.querySelector('.register-link');
    registerLink?.addEventListener('click', (e) => {
      e.preventDefault();
      const registerSection = document.getElementById('register');
      registerSection?.scrollIntoView({ behavior: 'smooth' });
    });
  }

  setupButtonActions() {
    const joinBtn = document.querySelector('[data-action="join"]');
    const exploreBtn = document.querySelector('[data-action="explore"]');

    joinBtn?.addEventListener('click', () => {
      const registerSection = document.getElementById('register');
      registerSection?.scrollIntoView({ behavior: 'smooth' });
    });

    exploreBtn?.addEventListener('click', () => {
      const communitySection = document.getElementById('community');
      communitySection?.scrollIntoView({ behavior: 'smooth' });
    });
  }

  updateYear() {
    document.getElementById('year').textContent = new Date().getFullYear();
  }
}

window.TC_JOIN_URL = window.TC_JOIN_URL || '';

document.addEventListener('DOMContentLoaded', () => {
  new LoadingManager();
  new NavigationManager();
  new UIManager();
  new CommunitiesManager();
  new MembersManager();
  new FormManager();

  if (window.location.hash === '#register') {
    const registerSection = document.getElementById('register');
    setTimeout(() => {
      registerSection?.scrollIntoView({ behavior: 'smooth' });
    }, 2500);
  }
});
