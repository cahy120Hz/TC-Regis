import { allowMethods, clearSession, type Req, type Res } from '../_lib/common.js';

export default function handler(req: Req, res: Res) {
  if (!allowMethods(req, res, ['POST'])) return;
  clearSession(res);
  res.json({ success: true });
}
