import { allowMethods, rateLimit, checkPassword, setSession, fail, type Req, type Res } from '../_lib/common.js';

export default async function handler(req: Req, res: Res) {
  if (!allowMethods(req, res, ['POST'])) return;
  if (!rateLimit(req, res, 'login', 5, 60_000)) return;
  try {
    const password = req.body?.password;
    if (!password || !checkPassword(password)) return void res.status(401).json({ error: 'Password salah' });
    setSession(res);
    res.json({ success: true });
  } catch (err) {
    fail(res, err, 'Login gagal');
  }
}
