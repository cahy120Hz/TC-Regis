import { allowMethods, requireAdmin, getSupabase, fail, type Req, type Res } from '../_lib/common.js';

export default async function handler(req: Req, res: Res) {
  if (!allowMethods(req, res, ['GET'])) return;
  if (!requireAdmin(req, res)) return;
  try {
    const limit = Math.min(Math.max(parseInt(String(req.query.limit ?? '50')) || 50, 1), 200);
    const offset = Math.max(parseInt(String(req.query.offset ?? '0')) || 0, 0);
    const search = String(req.query.search ?? '').trim().replace(/[,()%*]/g, '');

    let q = getSupabase()
      .from('registrations')
      .select('id, full_name, phone, tiktok, created_at', { count: 'exact' })
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (search) q = q.or(`full_name.ilike.%${search}%,phone.ilike.%${search}%,tiktok.ilike.%${search}%`);

    const { data, error, count } = await q;
    if (error) throw error;
    res.json({ success: true, data: data || [], total: count || 0 });
  } catch (err) {
    fail(res, err, 'Gagal memuat data anggota');
  }
}
