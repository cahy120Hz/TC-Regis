import { allowMethods, requireAdmin, getSupabase, fail, type Req, type Res } from '../../_lib/common.js';

// Cegah CSV injection (Excel menjalankan sel yang diawali = + - @)
const cell = (v: unknown) => {
  let s = String(v ?? '');
  if (/^[=+\-@\t\r]/.test(s)) s = "'" + s;
  return `"${s.replace(/"/g, '""')}"`;
};

export default async function handler(req: Req, res: Res) {
  if (!allowMethods(req, res, ['POST', 'GET'])) return;
  if (!requireAdmin(req, res)) return;
  try {
    const { data, error } = await getSupabase()
      .from('registrations')
      .select('full_name, phone, tiktok, created_at')
      .order('created_at', { ascending: false })
      .limit(10000);
    if (error) throw error;

    const rows = [['Nama', 'Telepon', 'TikTok', 'Terdaftar'].map(cell).join(',')];
    for (const r of data || []) rows.push([r.full_name, r.phone, '@' + r.tiktok, r.created_at].map(cell).join(','));

    res.setHeader('Content-Type', 'text/csv; charset=utf-8');
    res.setHeader('Content-Disposition', 'attachment; filename="tc-members.csv"');
    res.send('\uFEFF' + rows.join('\n'));
  } catch (err) {
    fail(res, err, 'Export gagal');
  }
}
