import { allowMethods, requireAdmin, getSupabase, fail, type Req, type Res } from '../_lib/common.js';

export default async function handler(req: Req, res: Res) {
  if (!allowMethods(req, res, ['GET'])) return;
  if (!requireAdmin(req, res)) return;
  try {
    const db = getSupabase();
    const startOfDay = new Date();
    startOfDay.setHours(0, 0, 0, 0);

    const [total, today, latest] = await Promise.all([
      db.from('registrations').select('id', { count: 'exact', head: true }),
      db.from('registrations').select('id', { count: 'exact', head: true }).gte('created_at', startOfDay.toISOString()),
      db.from('registrations').select('id, full_name, phone, tiktok, created_at').order('created_at', { ascending: false }).limit(5)
    ]);
    if (total.error) throw total.error;
    if (today.error) throw today.error;
    if (latest.error) throw latest.error;

    res.json({
      success: true,
      stats: {
        totalMembers: total.count || 0,
        todayRegistrations: today.count || 0,
        latestMembers: latest.data || []
      }
    });
  } catch (err) {
    fail(res, err, 'Gagal memuat statistik');
  }
}
