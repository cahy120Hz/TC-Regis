import { allowMethods, getSupabase, fail, type Req, type Res } from './_lib/common.js';

export default async function handler(req: Req, res: Res) {
  if (!allowMethods(req, res, ['GET'])) return;
  try {
    const limit = Math.min(Math.max(parseInt(String(req.query.limit ?? '12')) || 12, 1), 100);
    const offset = Math.max(parseInt(String(req.query.offset ?? '0')) || 0, 0);

    const { data, error } = await getSupabase()
      .from('public_registrations')
      .select('id, display_name, tiktok, created_at')
      .order('created_at', { ascending: false })
      .range(offset, offset + limit - 1);

    if (error) throw error;
    res.setHeader('Cache-Control', 'public, s-maxage=15, stale-while-revalidate=30');
    res.json({ success: true, data: data || [], count: data?.length || 0 });
  } catch (err) {
    fail(res, err, 'Failed to fetch members');
  }
}
