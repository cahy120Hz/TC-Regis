import type { VercelRequest, VercelResponse } from '@vercel/node';
import { createClient, type SupabaseClient } from '@supabase/supabase-js';
import crypto from 'node:crypto';

export type Req = VercelRequest;
export type Res = VercelResponse;

let client: SupabaseClient | null = null;

export function getSupabase(): SupabaseClient {
  if (client) return client;
  const url = process.env.SUPABASE_URL;
  const key = process.env.SUPABASE_SERVICE_ROLE_KEY;
  if (!url || !key) throw new Error('Supabase belum dikonfigurasi (SUPABASE_URL / SUPABASE_SERVICE_ROLE_KEY)');
  client = createClient(url, key, { auth: { persistSession: false } });
  return client;
}

export function secureHeaders(res: Res) {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('Cache-Control', 'no-store');
}

export function allowMethods(req: Req, res: Res, methods: string[]): boolean {
  secureHeaders(res);
  if (!methods.includes(req.method || '')) {
    res.setHeader('Allow', methods.join(', '));
    res.status(405).json({ error: 'Method not allowed' });
    return false;
  }
  return true;
}

// Rate limit sederhana (in-memory, per instance serverless; cukup untuk anti-spam dasar)
const hits = new Map<string, number[]>();
export function rateLimit(req: Req, res: Res, bucket: string, max: number, windowMs: number): boolean {
  const fwd = req.headers['x-forwarded-for'];
  const ip = (Array.isArray(fwd) ? fwd[0] : fwd)?.split(',')[0].trim() || req.socket?.remoteAddress || 'unknown';
  const key = `${bucket}:${ip}`;
  const now = Date.now();
  const recent = (hits.get(key) || []).filter(t => now - t < windowMs);
  recent.push(now);
  hits.set(key, recent);
  if (recent.length > max) {
    res.status(429).json({ error: 'Terlalu banyak permintaan. Coba lagi sebentar.' });
    return false;
  }
  return true;
}

export function validatePhone(phone: string): string | null {
  const cleaned = String(phone).replace(/[\s\-()]/g, '');
  if (!/^\+?\d{8,15}$/.test(cleaned)) return null;
  if (cleaned.startsWith('+')) return cleaned;
  if (cleaned.startsWith('0')) return '+62' + cleaned.slice(1);
  return '+' + cleaned;
}

export function validateTikTok(username: string): string | null {
  const cleaned = String(username).replace(/^@/, '').trim();
  return /^[\w.]{3,30}$/.test(cleaned) ? cleaned : null;
}

export async function sendTelegram(text: string) {
  const token = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;
  if (!token || !chatId) return;
  try {
    const ctrl = new AbortController();
    const t = setTimeout(() => ctrl.abort(), 5000);
    await fetch(`https://api.telegram.org/bot${token}/sendMessage`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ chat_id: chatId, text }),
      signal: ctrl.signal
    });
    clearTimeout(t);
  } catch (err) {
    console.error('Telegram gagal:', err);
  }
}

// ---------- Admin session (cookie bertanda tangan HMAC) ----------
const COOKIE = 'tc_admin';
const SESSION_MS = 8 * 60 * 60 * 1000;

function secret(): string {
  const s = process.env.SESSION_SECRET;
  if (!s || s.length < 16) throw new Error('SESSION_SECRET belum diisi (minimal 16 karakter)');
  return s;
}

const sign = (v: string) => crypto.createHmac('sha256', secret()).update(v).digest('hex');

function safeEqual(a: string, b: string): boolean {
  const ab = Buffer.from(a);
  const bb = Buffer.from(b);
  return ab.length === bb.length && crypto.timingSafeEqual(ab, bb);
}

export function checkPassword(password: string): boolean {
  const expected = (process.env.ADMIN_PASSWORD_HASH || '').toLowerCase();
  if (!expected) throw new Error('ADMIN_PASSWORD_HASH belum diisi');
  const given = crypto.createHash('sha256').update(String(password)).digest('hex');
  return safeEqual(given, expected);
}

function cookieAttrs(maxAgeSec: number): string {
  const secure = process.env.NODE_ENV === 'production' ? '; Secure' : '';
  return `Path=/api; HttpOnly; SameSite=Strict; Max-Age=${maxAgeSec}${secure}`;
}

export function setSession(res: Res) {
  const exp = String(Date.now() + SESSION_MS);
  res.setHeader('Set-Cookie', `${COOKIE}=${exp}.${sign(exp)}; ${cookieAttrs(SESSION_MS / 1000)}`);
}

export function clearSession(res: Res) {
  res.setHeader('Set-Cookie', `${COOKIE}=; ${cookieAttrs(0)}`);
}

export function requireAdmin(req: Req, res: Res): boolean {
  try {
    const raw = (req.headers.cookie || '').split(';').map(s => s.trim()).find(s => s.startsWith(COOKIE + '='));
    const val = raw?.slice(COOKIE.length + 1) || '';
    const [exp, sig] = val.split('.');
    if (exp && sig && safeEqual(sig, sign(exp)) && Number(exp) > Date.now()) return true;
  } catch (err) {
    console.error('Auth error:', err);
  }
  res.status(401).json({ error: 'Unauthorized' });
  return false;
}

export function fail(res: Res, err: unknown, msg = 'Terjadi kesalahan server') {
  console.error(msg, err);
  const detail = process.env.NODE_ENV !== 'production' && err instanceof Error ? ` (${err.message})` : '';
  res.status(500).json({ error: msg + detail });
}
