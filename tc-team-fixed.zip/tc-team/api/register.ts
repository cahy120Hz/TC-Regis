import { allowMethods, rateLimit, getSupabase, validatePhone, validateTikTok, sendTelegram, fail, type Req, type Res } from './_lib/common.js';

export default async function handler(req: Req, res: Res) {
  if (!allowMethods(req, res, ['POST'])) return;
  if (!rateLimit(req, res, 'register', 5, 60_000)) return;

  try {
    const { phone, fullname, tiktok } = req.body || {};
    if (!phone || !fullname || !tiktok) return void res.status(400).json({ error: 'Missing required fields' });

    const p = validatePhone(phone);
    if (!p) return void res.status(400).json({ error: 'Invalid phone number format' });

    const t = validateTikTok(tiktok);
    if (!t) return void res.status(400).json({ error: 'Invalid TikTok username format' });

    const name = String(fullname).trim();
    if (!name || name.length > 100) return void res.status(400).json({ error: 'Invalid full name' });

    const db = getSupabase();
    const { data, error } = await db
      .from('registrations')
      .insert([{ full_name: name, phone: p, tiktok: t }])
      .select('id')
      .single();

    if (error || !data) {
      console.error('DB error:', error);
      return void res.status(500).json({ error: 'Failed to save registration' });
    }

    const { error: pubErr } = await db
      .from('public_registrations')
      .insert([{ registration_id: data.id, display_name: name, tiktok: t }]);
    if (pubErr) console.error('Public registration error:', pubErr);

    await sendTelegram(`🎉 Pendaftaran Anggota Baru\n\n👤 Nama: ${name}\n📱 Nomor: ${p}\n🎵 TikTok: @${t}\n⏰ ${new Date().toLocaleString('id-ID', { timeZone: 'Asia/Jakarta' })}`);

    res.status(201).json({ success: true, message: 'Registration successful', id: data.id });
  } catch (err) {
    fail(res, err, 'An error occurred during registration');
  }
}
