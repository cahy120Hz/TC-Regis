const express = require('express');
const path = require('path');

const app = express();
const PORT = 3000;

app.use(express.json({ limit: '10kb' }));
app.use(express.static(path.join(__dirname, 'public')));

app.use((req, res, next) => {
  res.setHeader('X-Content-Type-Options', 'nosniff');
  res.setHeader('X-Frame-Options', 'DENY');
  res.setHeader('X-XSS-Protection', '1; mode=block');
  next();
});

let requestCounts = new Map();
let mockMembers = [
  { id: '1', display_name: 'Creator Demo 1', tiktok: 'creatorone', created_at: new Date().toISOString() },
  { id: '2', display_name: 'Developer Demo', tiktok: 'devdemo', created_at: new Date().toISOString() }
];

const rateLimit = (maxRequests, windowMs) => {
  return (req, res, next) => {
    const key = req.ip || 'unknown';
    const now = Date.now();
    const times = requestCounts.get(key) || [];
    
    const validTimes = times.filter(t => now - t < windowMs);
    validTimes.push(now);
    
    if (validTimes.length > maxRequests) {
      res.status(429).json({ error: 'Too many requests. Please try again later.' });
      return;
    }
    
    requestCounts.set(key, validTimes);
    next();
  };
};

const validatePhone = (phone) => {
  const cleaned = phone.replace(/[\s\-()]/g, '');
  
  if (!cleaned.match(/^[\+\d]{8,}$/)) {
    return null;
  }
  
  if (!cleaned.startsWith('+')) {
    if (cleaned.startsWith('0')) {
      return '+62' + cleaned.substring(1);
    }
    return '+' + cleaned;
  }
  
  return cleaned;
};

const validateTikTok = (username) => {
  const cleaned = username.replace('@', '').trim();
  
  if (!/^[\w.]{3,}$/.test(cleaned)) {
    return null;
  }
  
  return cleaned;
};

app.post('/api/register', rateLimit(5, 60 * 1000), (req, res) => {
  try {
    const { phone, fullname, tiktok } = req.body;

    if (!phone || !fullname || !tiktok) {
      res.status(400).json({ error: 'Missing required fields' });
      return;
    }

    const validatedPhone = validatePhone(phone);
    if (!validatedPhone) {
      res.status(400).json({ error: 'Invalid phone number format' });
      return;
    }

    const validatedTikTok = validateTikTok(tiktok);
    if (!validatedTikTok) {
      res.status(400).json({ error: 'Invalid TikTok username format' });
      return;
    }

    if (fullname.trim().length === 0 || fullname.trim().length > 100) {
      res.status(400).json({ error: 'Invalid full name' });
      return;
    }

    const newMember = {
      id: 'mock-' + Date.now(),
      display_name: fullname.trim(),
      tiktok: validatedTikTok,
      created_at: new Date().toISOString()
    };

    mockMembers.unshift(newMember);
    
    console.log(`✓ New registration: ${fullname} (@${validatedTikTok})`);

    res.status(201).json({
      success: true,
      message: 'Registration successful',
      id: newMember.id
    });
  } catch (error) {
    console.error('Registration error:', error);
    res.status(500).json({ error: 'An error occurred during registration' });
  }
});

app.get('/api/members', (req, res) => {
  try {
    const limitStr = req.query.limit || '12';
    const offsetStr = req.query.offset || '0';
    const limit = Math.min(parseInt(limitStr), 100);
    const offset = parseInt(offsetStr);

    const members = mockMembers.slice(offset, offset + limit);

    res.json({
      success: true,
      data: members,
      count: members.length,
      total: mockMembers.length
    });
  } catch (error) {
    console.error('Members error:', error);
    res.status(500).json({ error: 'Failed to fetch members' });
  }
});

app.get('/api/members/stream', (req, res) => {
  res.setHeader('Content-Type', 'text/event-stream');
  res.setHeader('Cache-Control', 'no-cache');
  res.setHeader('Connection', 'keep-alive');
  res.setHeader('Access-Control-Allow-Origin', '*');

  res.write('data: {"event":"stream_connected"}\n\n');

  const interval = setInterval(() => {
    res.write('data: {"event":"heartbeat"}\n\n');
  }, 30000);

  req.on('close', () => {
    clearInterval(interval);
    res.end();
  });
});

app.get('/health', (req, res) => {
  res.json({ 
    status: 'ok', 
    timestamp: new Date().toISOString(),
    mode: 'development (mock mode)',
    members: mockMembers.length
  });
});

app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

app.listen(PORT, () => {
  console.log(`
╔════════════════════════════════════════════════════════════════╗
║                                                                ║
║        TC — THE CREATOR COMMUNITY                             ║
║        Development Server Running ✓                           ║
║                                                                ║
║        🌐 http://localhost:${PORT}                               ║
║                                                                ║
╚════════════════════════════════════════════════════════════════╝

✓ Server started on port ${PORT}
✓ Frontend: http://localhost:${PORT}
✓ Admin: http://localhost:${PORT}/admin.html
✓ API Health: http://localhost:${PORT}/health

Mock Members: ${mockMembers.length}

Press Ctrl+C to stop
`);
});
