# TC — The Creator Community

Landing page + pendaftaran anggota + admin panel. Frontend statis (`public/`), backend Vercel Serverless Functions (`api/`), database Supabase, notifikasi Telegram.

## Struktur
```
api/
  _lib/common.ts         helper bersama (supabase, auth, rate limit, validasi)
  register.ts            POST /api/register
  members.ts             GET  /api/members
  admin/login.ts         POST /api/admin/login
  admin/logout.ts        POST /api/admin/logout
  admin/stats.ts         GET  /api/admin/stats
  admin/registrations.ts GET  /api/admin/registrations
  admin/export/csv.ts    POST /api/admin/export/csv
migrations/001_initial_schema.sql
public/                  index.html, admin.html, js, styles, assets
dev-server.ts            server lokal (pakai handler api/ yang sama)
server.cjs               server mock tanpa database (hanya lihat tampilan)
```

## Setup
1. `npm install`
2. **Supabase**: buat project -> SQL Editor -> jalankan `migrations/001_initial_schema.sql`. Ambil URL + service_role key di Settings -> API.
3. `cp .env.example .env`, isi semua nilainya (cara bikin hash admin & SESSION_SECRET ada di komentar file).
4. `npm run dev` -> http://localhost:3000 (admin: `/admin.html`).
   Tanpa database, cuma lihat tampilan: `npm run mock`.

## Deploy (Vercel)
1. Push ke GitHub.
2. vercel.com -> Add New -> Project -> import repo.
3. Settings -> Environment Variables: isi semua variabel dari `.env.example` (NODE_ENV tidak perlu).
4. Deploy. Atau: `npx vercel --prod`.

## Catatan
- Login admin memakai cookie bertanda tangan (HttpOnly, 8 jam).
- Daftar anggota di halaman depan refresh tiap 30 detik (polling).
- Rate limit in-memory per instance, cukup untuk anti-spam dasar.
